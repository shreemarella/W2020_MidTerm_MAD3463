/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lambton;




import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Pritesh Patel
 */
public class LambtonStringTools 
{
    private static int lengthofString(String rev)
    {
        System.out.println("rev = " + rev.length());
        return 0;
    }

    //1 - REVERSE STRING
    public static String reverse(String s)
    {
        String txt="Failure will never overtake me if my determination to succeed is strong enough";
        System.out.println("length of string text : " + txt.length());
        for(int i=0;i<txt.length()/2;i++)
        {
            for( int j=0;j<txt.length()-1;j--)
            {
                int temp=
            }

        }

        
        return s;
    }



    //2 - FORMAT INITIALS OF STRING
    public static String initials(String s) 
    {
        String splittedArray[]= splitTheStringIntoArray(s);
        String init="";
        for(String s=0;)
        {

        }
    }


        
    //3 - FIND MOST FREQUENT CHARACTER FROM STRING
    public static String mostFrequent(String s)
    {
           return s;
    }



    //4 - CONVERT BINARY NUMBER TO DECIMALS
    public static int binaryToDecimal(String s) 
    {
       return 0;
    }
     
    //5 - REPLACING SUBSTRING WITH NEW STRING IN EXISTING STRING
    public static String replaceSubString(String originalString, String findString, String newString) 
    {
        String[] subString=originalString.split(originalString,5);
        String temp=null;
        for(int i=0; i<originalString.length();i++)
        for (int j = 0; j<lengthofString(i); j++)
        {
                System.out.println();
            }
        return null;

}
